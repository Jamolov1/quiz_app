import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/model/test_model.dart';
import 'package:quiz_app/pages/result_page.dart';
import 'package:quiz_app/widgets/item_variant_quiz.dart';

class QuizPage extends StatefulWidget {
  List<TestModel> quizs;
  String name;

  QuizPage({super.key, required this.name, required this.quizs});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int currentQuistionCount = 0;
  int expendedValue = 1;
  final CountDownController _controller = CountDownController();
  int trueQuistionCount = 0;
  String isSelected = "";
  List<String> choseAnswers = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF004643),
        title: const Text(
          "Start Test",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 26,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.name,
              style: const TextStyle(
                color: Colors.blue,
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            SizedBox(
              height: 60,
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        border: Border.all(width: 1.5, color: Colors.grey),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.all(3),
                              margin: const EdgeInsets.symmetric(horizontal: 6),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.shade200,
                                      spreadRadius: 4,
                                      blurRadius: 4,
                                      offset: const Offset(1, 3),
                                    )
                                  ]),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: expendedValue,
                                    child: Container(
                                      decoration: BoxDecoration(
                                          color: Colors.yellow,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                    ),
                                  ),
                                  Expanded(
                                    flex: widget.quizs.length - expendedValue,
                                    child: Container(),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Text(
                            "$expendedValue/${widget.quizs.length}",
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: CircularCountDownTimer(
                        controller: _controller,
                        width: 50,
                        height: 50,
                        duration: 10,
                        fillColor: const Color(0xFF004643),
                        ringColor: const Color(0xFFABD1C6),
                        isReverse: true,
                        onComplete: () {
                          if (currentQuistionCount < widget.quizs.length) {
                            setState(() {
                              expendedValue++;
                              currentQuistionCount++;
                              isSelected = "";
                              choseAnswers.add("Xato");
                            });
                            _controller.restart();
                          }
                        },
                      )),
                ],
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            Text(
              "Question:${widget.quizs.length}",
              style: const TextStyle(
                color: Colors.blue,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Text(
              widget.quizs[expendedValue].quiz,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            ItemVariantQuiz(
              testVariant: widget.quizs[expendedValue].a,
              isSelected: isSelected == "A",
              ontTap: () {
                setState(() {
                  isSelected = "A";
                });
              },
            ),
            ItemVariantQuiz(
              testVariant: widget.quizs[expendedValue].b,
              isSelected: isSelected == "B",
              ontTap: () {
                setState(() {
                  isSelected = "B";
                });
              },
            ),
            ItemVariantQuiz(
              testVariant: widget.quizs[expendedValue].c,
              isSelected: isSelected == "C",
              ontTap: () {
                setState(() {
                  isSelected = "C";
                });
              },
            ),
            ItemVariantQuiz(
  testVariant: widget.quizs[expendedValue].d,
              isSelected: isSelected == "D",
              ontTap: () {
                setState(() {
                  isSelected = "D";
                });
              },
            ),
            SizedBox(
              height: 30,
            ),
            InkWell(
              onTap: () {
                setState(() {
                  if (isSelected != "") {
                    _controller.restart();
                    if (currentQuistionCount + 1 < widget.quizs.length) {
                      if (isSelected ==
                          widget.quizs[currentQuistionCount].trueAnswer) {
                        choseAnswers.add("Tug'ri");
                        trueQuistionCount++;
                        expendedValue++;
                        currentQuistionCount++;
                        isSelected = "";
                      } else {
                        choseAnswers.add("Xato");
                        expendedValue++;
                        currentQuistionCount++;
                        isSelected = "";
                      }
                    } else if (currentQuistionCount + 1 ==
                        widget.quizs.length) {
                      if (isSelected ==
                          widget.quizs[currentQuistionCount].trueAnswer) {
                        choseAnswers.add("Tug'ri");
                        trueQuistionCount++;
                        expendedValue++;
                        Navigator.push(context, MaterialPageRoute(builder: (_) {
                          return ResultPage(
                            truefalseAnswers: choseAnswers,
                          );
                        }));
                      }
                    }
                  }
                });
              },
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 40),
                height: 56,
                decoration: BoxDecoration(
                  color: Color(0xFF004643),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Center(
                  child: Text(
                    "Next",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
