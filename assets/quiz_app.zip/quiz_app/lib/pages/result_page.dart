import 'package:flutter/material.dart';

class ResultPage extends StatefulWidget {
  List<String> truefalseAnswers;
  ResultPage({super.key,required this.truefalseAnswers});

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(widget.truefalseAnswers);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
