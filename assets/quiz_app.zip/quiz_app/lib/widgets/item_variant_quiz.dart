import 'package:flutter/material.dart';


class ItemVariantQuiz extends StatelessWidget {
  String testVariant;
  bool isSelected;
  VoidCallback ontTap;

  ItemVariantQuiz(
      {super.key, required this.testVariant, required this.isSelected,required this.ontTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontTap,
      child: Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade400,
              blurRadius: 17,
              spreadRadius: 2,
              offset: const Offset(1, 3),
            )
          ],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              testVariant,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 15, fontWeight: FontWeight.bold,
              ),
            ),
            isSelected
                ? const Icon(Icons.check_circle_outline, color: Colors.green,)
                : Container(),
          ],
        ),
      ),
    );
  }
}
