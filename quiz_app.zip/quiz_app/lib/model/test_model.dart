class TestModel {
  String quiz;
  String a;
  String b;
  String c;
  String d;
  String trueAnswer;

  TestModel({
    required this.quiz,
    required this.a,
    required this.b,
    required this.c,
    required this.d,
    required this.trueAnswer,
  });
}
